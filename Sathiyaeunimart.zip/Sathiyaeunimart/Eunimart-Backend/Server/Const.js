export const PORT = 8000;

export const mongoUrl = "mongodb+srv://sathiyabanur2020cse:Banu123@cluster0.czbu5h1.mongodb.net/Cluster0?retryWrites=true&w=majority"